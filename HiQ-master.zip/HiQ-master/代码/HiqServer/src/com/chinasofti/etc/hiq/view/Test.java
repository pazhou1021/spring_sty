package com.chinasofti.etc.hiq.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;

import javax.swing.JFrame;
import javax.swing.Timer;






//public class Test implements ActionListener{
//
//	public Timer time;
//	public Test(){
//		System.out.println(">>>>>>>>>>>");
//		time = new Timer(1000, this);
//		time.start();
//	}
//
//	
//	
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		 Test test = new Test();
//		 while(true){
//			 
//		 }
//	}
//
//
//
//	public void actionPerformed(ActionEvent e) {
//		// TODO Auto-generated method stub
//		System.out.println("aaaaa");
//		if(e.getSource()==time)
//			System.out.println("ttt");
//		time.restart();
//	}
//
//
//
//
//}
class Test {
	
	public static void main(String args[]){
		ttt k = new ttt();
		k.start();
	}
}
