package com.chinasofti.etc.hiq.biz;

public interface InitDataBaseBiz {
	void InitDataBase();
}
