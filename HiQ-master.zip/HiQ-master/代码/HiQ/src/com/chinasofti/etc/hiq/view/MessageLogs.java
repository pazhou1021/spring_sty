package com.chinasofti.etc.hiq.view;

public class MessageLogs {
	
}
