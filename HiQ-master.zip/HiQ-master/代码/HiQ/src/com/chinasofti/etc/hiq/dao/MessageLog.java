package com.chinasofti.etc.hiq.dao;

public interface MessageLog {
	boolean insertMessage(String msg);
}
