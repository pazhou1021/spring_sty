package com.chinasofti.etc.hiq.view;

public class Client {
//	private int ServerPort = 0;
//	private String ServerIP = null;
//	private Socket mySocket = null;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LoginUI("�����½");
	}

	public Client() {
		// TODO Auto-generated constructor stub
	}
}
