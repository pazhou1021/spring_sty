package com.chinasofti.etc.hiq.po;

public class Tools {

}
